const jsforce = require('jsforce');
const token = "3Z0JPnEszFXnnEStIgDW1KOe";
const username = "yrliu615@sandbox.com";
const password = "Shoutao.7261";
const loginUrl = "https://login.salesforce.com";
const conn = new jsforce.Connection({
    loginUrl: loginUrl
});

module.exports = {
    conn:conn,
    token:token,
    username:username,
    password:password,
}