const express = require('express');
const jsforce = require('jsforce');
const cors = require('cors');
const bodyParser = require('body-parser');
const appSource = require("../server/util/app-source.js");
const conn = appSource.conn;
const token = appSource.token;
const username = appSource.username;
const password = appSource.password;

const app = express();
const PORT = 3000;

app.use(cors({
    origin: 'http://localhost:4200'
}));
app.use(bodyParser.json());

app.get('/', function(req, res){
    res.send('Trail!');
})

app.post('/contacts', async (req, res) => {
    conn.login(username, password + token, function (err, userInfo) {
        if (err) { return console.log(err); }
        try {
            console.log('forms= ' + req.body);
            conn.sobject("Contact")
                .find(
                    {
                        Email: req.body.email,
                        'Account.Name' : req.body.companyName
                    },
                ).execute(function (err, records) {
                    console.log("fetched: " + records.length);
                    res.send({
                        status: 'success',
                        totalSize: records.length,
                        records: records,
                    });
                })
        } catch (err) {
            console.log("err= ", err);
        }
    })
});

app.listen(PORT, () => {
    console.log(`Server running on port ${PORT}`);
})
