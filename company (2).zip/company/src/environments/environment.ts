export const environment = {
    hostUrl: 'http://localhost:4200',
    nodeUrl: 'http://localhost:3000',
}