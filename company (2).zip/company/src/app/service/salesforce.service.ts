import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { response } from 'express';
import { Observable, map } from 'rxjs';
import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root'
})
export class SalesforceService {

  constructor(private http: HttpClient) { }

  getContact(param: object): Observable<any> {
    console.log(param);
    return this.http.post(`${environment.nodeUrl}/contacts`, param);
  }

  getSubscription(param: object) {
    return this.http.post(`${environment.nodeUrl}/api/trail/getSubscription`, param);
  }
  createTrailSubscription(param: object) {
    return this.http.post(`${environment.nodeUrl}/api/trail/createTrailSubscription`, param);
  }



}
