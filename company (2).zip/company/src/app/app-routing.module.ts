import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { FormsComponent } from './forms/forms.component';
import { SubResultComponent } from './sub-result/sub-result.component';

const routes: Routes = [
  { path: '', component: FormsComponent },
  { path: 'sub-result', component: SubResultComponent },
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
