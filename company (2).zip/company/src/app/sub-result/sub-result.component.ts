import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-sub-result',
  templateUrl: './sub-result.component.html',
  styleUrls: ['./sub-result.component.scss']
})
export class SubResultComponent implements OnInit {
  result: string;

  ngOnInit() {
    const name = JSON.parse(localStorage.getItem('company-sub') || '{}').name;
    console.log("name: " + name);
    this.result = name;
  }

}
