import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { MatDialog } from '@angular/material/dialog';
import { VerifyDialogComponent } from '../verify-dialog/verify-dialog.component';
import { Router } from '@angular/router';
import { SalesforceService } from '../service/salesforce.service';

export interface DialogData {
  animal: string;
  name: string;
}

@Component({
  selector: 'app-forms',
  templateUrl: './forms.component.html',
  styleUrls: ['./forms.component.scss']
})
export class FormsComponent implements OnInit {

  animal: string;
  name: string;


  accountDetailsForm: FormGroup;

  constructor(private fb: FormBuilder, public dialog: MatDialog, private router: Router, private salesforceService: SalesforceService) { }

  ngOnInit() {
    // user links form validations
    this.accountDetailsForm = this.fb.group({
      companyName: new FormControl('', Validators.compose([
        //  Validators.maxLength(25),
        //  Validators.minLength(5),
        //  Validators.pattern('^(?=.*[a-zA-Z])(?=.*[0-9])[a-zA-Z0-9]+$'),
        Validators.required
      ])),
      name: new FormControl('', Validators.compose([
        Validators.required
      ])),
      email: new FormControl('', Validators.compose([
        Validators.required,
        Validators.pattern('^[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+.[a-zA-Z0-9-.]+$')
      ])),
      code: new FormControl('', Validators.compose([
        Validators.required
      ])),
      terms: new FormControl(false, Validators.pattern('true'))
    })
  }

  onSubmitAccountDetails(value: any) {
    console.log(value);
    console.log("name in form: " + value.name);
    localStorage.setItem('company-sub', JSON.stringify(value));

    this.salesforceService.getContact(value).subscribe((data: any = {}) => {
      if(data.totalSize > 0) {
        this.router.navigate(['sub-result']);
      }else {
        const dialogRef = this.dialog.open(VerifyDialogComponent, {
          data: { name: this.name, animal: this.animal },
        });
    
        dialogRef.afterClosed().subscribe(result => {
          console.log('The dialog was closed');
          this.animal = result;
          console.log('dialog result: ' + result);
        });
      }
    })
    
  }


}
